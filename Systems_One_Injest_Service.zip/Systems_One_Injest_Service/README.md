# Systems One MQTT Ingest Service

Python service that subscribes to MQTT topics, parses device payloads, and writes to SQL Server.

## Quick start (Windows)

1) Create/activate venv

- `python -m venv .venv`
- `.venv\Scripts\activate`

2) Install deps

- `pip install -r mqtt_ingest/requirements.txt`

3) Configure environment

- Copy `.env.example` to `.env`
- Fill in your MQTT + SQL Server settings

4) Run

- `python -m mqtt_ingest`

Alternative (script shim):
- `python run_ingest.py`

## Environment variables

See `.env.example` for the full list.

Key toggles:
- `DB_ENABLE=true` enables DB writes.
- `DB_CONNECT_ON_START=true` runs a DB healthcheck before starting MQTT.
- `RUN_SECONDS=960` runs for a fixed duration (handy for diagnostics).

## Deployment notes

- Prefer setting real environment variables (or a secret store) instead of committing `.env`.
- Ensure the SQL Server ODBC driver is installed (default: `ODBC Driver 18 for SQL Server`).
- If running under a Windows service wrapper (NSSM / Task Scheduler), run `python -m mqtt_ingest` from the repo root and set environment variables in the service configuration.

## Useful diagnostics

- SQL table inspection: `python -m mqtt_ingest.db_inspect_device_statistics`
- 15-minute insert verification: `python -m mqtt_ingest.statistics_15min_diagnostics` (set `RUN_SECONDS=960`)
