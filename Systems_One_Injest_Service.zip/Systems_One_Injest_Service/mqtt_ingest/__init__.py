"""MQTT ingest service.

Run with:
  python -m mqtt_ingest

Most configuration is via environment variables (see .env.example).
"""
